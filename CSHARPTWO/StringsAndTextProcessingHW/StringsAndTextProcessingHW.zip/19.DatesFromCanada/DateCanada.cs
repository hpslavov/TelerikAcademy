﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Globalization;

namespace _19.DatesFromCanada
{
    class DateCanada
    {

        //Write a program that extracts from a given text all dates that match the format DD.MM.YYYY.
        //Display them in the standard date format for Canada.
        static void Main()
        {
            string text = Console.ReadLine();

           
        }
    }
}
